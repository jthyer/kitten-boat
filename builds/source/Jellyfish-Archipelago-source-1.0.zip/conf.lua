function love.conf(t)
    t.window.width = 640
    t.window.height = 640
end