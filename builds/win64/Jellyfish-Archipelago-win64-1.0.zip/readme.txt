Jellyfish Archipelago

a game by John Thyer (farawaytimes.itch.io)

made with Love2D (love2d.org), Bosca Ceoil (boscaceoil.net), Piskel (piskelapp.com), and OGMO Editor (ogmo-editor-3.github.io)

BetterComicSans font by Quinn Davis Type: fontspace.com/qd-better-comic-sans-font-f41648

late submission to Sylvie's Jam #1: itch.io/jam/sylvies-jam-1

move with arrow keys, skip text with space, escape to quit, F to toggle fullscreen

debug commands: pageup goes to previous level, pagedown skips to next level